<?php include_once $_SERVER['DOCUMENT_ROOT']."/_partials/header.php"; ?>

<?php
session_unset();
session_destroy();
header("Location: login?warning=Boli ste odhlásený!");
die();
?>

<?php include_once $_SERVER['DOCUMENT_ROOT']."/_partials/footer.php"; ?>
